﻿using System;
namespace MarketProject
{
    public class CosmeticProduct : Product
    {
        private bool matiere; // liquide ou solide
        //private static int nbInstance3 = 0;


        public CosmeticProduct(int reference, string label, int stock, int achat, int vente_ht, int taille, string marque) : base(reference, label, stock, achat, vente_ht)
        {
            this.reference = reference;
            this.label = label;
            this.stock = stock;
            this.achat = achat;
            this.vente_ht = vente_ht;
            this.matiere = false;
            //nbInstance3++;
        }
        public CosmeticProduct()
        {
            this.reference = 0000;
            this.label = "none";
            this.stock = 0;
            this.achat = 0;
            this.vente_ht = 0;
            this.matiere = false;
        }

        override
        public double GetTTC()
        {
            return this.vente_ht + (this.vente_ht * 0.22);
        }

        public bool Matiere { get => matiere; set => matiere = value; }
    }
}
