﻿using System;
namespace MarketProject
{
    public class ElecProduct : Product
    {
        private int taille; //1 pour petit, 2 pour moyen, 3 pour grand
        private string marque;
        //private static int nbInstance2 = 0; 


        public ElecProduct(int reference, string label, int stock, int achat, int vente_ht, int taille, string marque) : base(reference, label, stock, achat, vente_ht)
        {
            this.reference = reference;
            this.label = label;
            this.stock = stock;
            this.achat = achat;
            this.vente_ht = vente_ht;
            this.taille = taille;
            this.marque = marque;
            //nbInstance2++;
        }

        public ElecProduct()
        {
            this.reference = 0000;
            this.label = "none";
            this.stock = 0;
            this.achat = 0;
            this.vente_ht = 0;
            this.taille = 0;

        }

        override
        public double GetTTC()
        {
            return this.vente_ht + (this.vente_ht * 0.20);
        }

        public int Taille { get => taille; set => taille = value; }
        public string Marque { get => marque; set => marque = value; }
    }
}
