﻿using System;
namespace MarketProject
{
    public class FoodProduct : Product
    {
        private readonly DateTime limit;
        //private static int nbInstance1 = 0;

        public FoodProduct(int reference, string label, int stock, int achat, int vente_ht, DateTime date) : base(reference,label,stock,achat,vente_ht)
        {
            this.reference = reference;
            this.label = label;
            this.stock = stock;
            this.achat = achat;
            this.vente_ht = vente_ht;
            this.limit = date;
            //nbInstance1++;
        }

        public FoodProduct()
        {
            this.reference = 0000;
            this.label = "none";
            this.stock = 0;
            this.achat = 0;
            this.vente_ht = 0;
            this.limit = new DateTime(2000 / 01 / 01);

        }

        override
        public double GetTTC()
        {
            return this.vente_ht + (this.vente_ht * 0.18);
        }
    }
}
