﻿using System;
namespace MarketProject
{
    public abstract class Fournisseur
    {
        protected int stock;


        protected Fournisseur()
        {
            this.stock = 0;
        }

        protected Fournisseur(int stock)
        {
            this.stock = stock;
        }

        public virtual double GetTTC(Product product)
        {
            return 0; 
        }

        public virtual double Approvisionne(int app, Marketplace retailer, Product product)
        {
            return 0;
        }

        public int Stock { get => stock; set => stock = value; }
    }
}
