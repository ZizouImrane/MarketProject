﻿using System;
namespace MarketProject
{
    public class FournisseurAlim : Fournisseur
    {
        private int nb_alim;

        public FournisseurAlim()
        {
            this.stock = 0;
        }

        public FournisseurAlim(int stock) 
        {
            this.stock = stock;
        }



        override
        public double Approvisionne(int app, Marketplace retailer, Product product)
        {
            if (app <= product.Stock)
            {
                product.Stock = product.Stock - app;
                nb_alim = app;
                //prix de vente
                return product.GetTTC();
            }

            else if (app == 0)
            {
                throw new NotImplementedException("On ne peut pas réapprovisionner de 0 produit.");
            }
            else
            {
                return 0;
            }



        }
        public int Nb_alim { get => nb_alim; set => nb_alim = value; }
    }
}
