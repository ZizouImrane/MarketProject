﻿using System;
namespace MarketProject
{
    public class FournisseurElec : Fournisseur
    {

        private int nb_elec;
        private Product product;


        public FournisseurElec()
        {
            this.stock = 0;
        }

        public FournisseurElec(int four)
        {
            this.stock = four;
        }


        override
        public double Approvisionne(int app, Marketplace retailer, Product product)
        {
            if (app <= product.Stock)
            {
                product.Stock = product.Stock - app;
                nb_elec = app;
                //prix de vente
                return product.GetTTC();
            }

            else if (app == 0)
            {
                throw new NotImplementedException("On ne peut pas réapprovisionner de 0 produit.");
            }
            else
            {
                return 0;
            }



        }

        public int Nb_elec { get => nb_elec; set => nb_elec = value; }
    }
}
