﻿
    /* je ne vois pas où faire d'interface, 
     * on aurait pu le faire pour fournisseur,
     * mais fournisseur a besoin d'un attribut "stock"
     * pour la quantité de stock disponible */

using System;
namespace MarketProject
{
    public class Marketplace {

        private int product_alim;
        private int product_elec;
        private int product_cosm;
        private int market_stock;

        public Marketplace()
        {
            this.product_alim = 0;
            this.product_elec = 0;
            this.product_cosm = 0;
            this.market_stock = 0;
        }

        public Marketplace(int m_stock)
        {
            this.market_stock = m_stock;
        }

        public int Product_alim { get => product_alim; set => product_alim = value; }
        public int Product_elec { get => product_elec; set => product_elec = value; }
        public int Product_cosm { get => product_cosm; set => product_cosm = value; }
        public int Market_stock { get => market_stock; set => market_stock = value; }

        public int GetProductNumber()
        {
            return this.product_alim + this.product_elec + this.product_cosm;
        }

        public bool SellProduct(int nb, Product product)
        {
            if (nb > product.Stock)
            {
                return false;
            }
            else
            {
                product.Stock = product.Stock - nb;
                return true;
            }
        }

        public string compare



        
    }
}