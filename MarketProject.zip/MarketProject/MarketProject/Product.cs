﻿using System;
namespace MarketProject
{
    abstract public class Product
    {

        /* 
        On aurait pu utiliser un static qu'on 
        incrémente a chaque création d'un produit pour avoir 
        le nombre de produits mais le problème est que si on veut 
        approvisionner de 500 produits on ne va pas instancier 500 objets
        de type produit. Donc je l'ai fait simplement dans mes methodes d'approvisionnement.
               
         */


        protected int reference;
        protected string label;
        protected int stock;
        protected int achat;
        protected int vente_ht;

        public int Reference { get => reference; set => reference = value; }
        public string Label { get => label; set => label = value; }
        public int Stock { get => stock; set => stock = value; }
        public int Achat { get => achat; set => achat = value; }
        public int Vente_ht { get => vente_ht; set => vente_ht = value; }

        protected Product(int reference, string label, int stock, int achat, int vente_ht)
        {
            this.reference = reference;
            this.label = label;
            this.stock = stock;
            this.achat = achat;
            this.vente_ht = vente_ht;
        }

        protected Product()
        {

        }


        public virtual double GetTTC()
        {
            return 0;
        }
    }
}
